package interfaceGui;

public class GameLauncher{
	
	public static void main(String[] args) {
		new Window();		
	}
}
